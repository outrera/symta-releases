(defpackage :symta (:use :cl))
